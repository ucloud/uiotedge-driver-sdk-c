var group__conn_group =
[
    [ "Management", "group__conn_mgt_group.html", "group__conn_mgt_group" ],
    [ "Publishing", "group__conn_pub_group.html", "group__conn_pub_group" ],
    [ "Subscribing", "group__conn_sub_group.html", "group__conn_sub_group" ]
];