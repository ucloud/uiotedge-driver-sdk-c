var group__library_group =
[
    [ "nats_Open", "group__library_group.html#ga4a26d4caecb23348f6eee862c95fee7d", null ],
    [ "nats_GetVersion", "group__library_group.html#gafc09930d38dcf3dcee144e8d3ffc225d", null ],
    [ "nats_GetVersionNumber", "group__library_group.html#ga5fbbaa19b0290b654d2669a05bd512e8", null ],
    [ "nats_CheckCompatibility", "group__library_group.html#ga8c2ad4df801bd9d11564587ed3a7081e", null ],
    [ "nats_Now", "group__library_group.html#gaa3c10ba3ae001595007ad0dc5dccc15e", null ],
    [ "nats_NowInNanoSeconds", "group__library_group.html#gacf5e423920d6a647df3bbf7de39d5223", null ],
    [ "nats_Sleep", "group__library_group.html#gad5040264cd4b1404956babf3c03a4f09", null ],
    [ "nats_GetLastError", "group__library_group.html#ga2610d5691a89a0f2526989083bee0fd3", null ],
    [ "nats_GetLastErrorStack", "group__library_group.html#gaca24172e1b97ca01cee29ca437f5702e", null ],
    [ "nats_PrintLastErrorStack", "group__library_group.html#ga5fab3b18c4fe3630254483575f6066f4", null ],
    [ "nats_SetMessageDeliveryPoolSize", "group__library_group.html#gab21e94ce7a7d226611ea2c05914cf19d", null ],
    [ "nats_ReleaseThreadMemory", "group__library_group.html#gafe171baefa00a85b77205116e9f3e48a", null ],
    [ "nats_Close", "group__library_group.html#gae75131e0ce4e5b89d0f82ea7892f112e", null ],
    [ "nats_CloseAndWait", "group__library_group.html#gaf75bb5b38bf32e6a8f43e54068625903", null ]
];