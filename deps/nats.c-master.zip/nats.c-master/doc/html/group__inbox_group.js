var group__inbox_group =
[
    [ "natsInbox_Create", "group__inbox_group.html#ga3d59c517d5aa0827b22e66a308a8fe6e", null ],
    [ "natsInbox_Destroy", "group__inbox_group.html#gac3db6bd01235144886cb0ee5cf444048", null ]
];