var group__types_group =
[
    [ "natsConnection", "group__types_group.html#gaf88dca0a18efb5c5e994d265a9f04aec", null ],
    [ "natsStatistics", "group__types_group.html#ga57a4b8c7109e2773878655722ce028aa", null ],
    [ "natsSubscription", "group__types_group.html#ga87158ec63b4f90f69e20451624ea01d8", null ],
    [ "natsMsg", "group__types_group.html#gadcab54026c4ed78f344ce03ce31bb61a", null ],
    [ "natsOptions", "group__types_group.html#gabcc48b40a81fe302188f4ee06ea9c54e", null ],
    [ "natsInbox", "group__types_group.html#ga206c3d4d6f4f6f96fd2cae53a3df31c1", null ],
    [ "stanConnection", "group__types_group.html#ga9e826493769d23086cfccefe95cdf64c", null ],
    [ "stanSubscription", "group__types_group.html#gae4dae869fb614536f0f027c2e2660cc5", null ],
    [ "stanMsg", "group__types_group.html#ga2cf5db7703b42d97abe56a3e83b2a87d", null ],
    [ "stanConnOptions", "group__types_group.html#ga13d64411878ba13a6ca39c915f2447c1", null ],
    [ "stanSubOptions", "group__types_group.html#ga023712711f5c289663fc2223e83686d3", null ]
];