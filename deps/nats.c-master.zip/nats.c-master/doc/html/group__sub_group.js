var group__sub_group =
[
    [ "natsSubscription_NoDeliveryDelay", "group__sub_group.html#ga38f1e41fc7619101fc4aa52014dd5428", null ],
    [ "natsSubscription_NextMsg", "group__sub_group.html#ga6538a5d78dfb0f16514b94c8e74c11af", null ],
    [ "natsSubscription_Unsubscribe", "group__sub_group.html#gaee87f8be0e6c2a4693ba2cea070583ba", null ],
    [ "natsSubscription_AutoUnsubscribe", "group__sub_group.html#ga09f285de2746a6e27fc66efd60bd3116", null ],
    [ "natsSubscription_QueuedMsgs", "group__sub_group.html#ga8a37b2d5290da3aecc05483d79e7e254", null ],
    [ "natsSubscription_SetPendingLimits", "group__sub_group.html#ga68a7cea89e75c529a7dd3bb77303dda4", null ],
    [ "natsSubscription_GetPendingLimits", "group__sub_group.html#ga786bb458981274fe717f266bd3b96d96", null ],
    [ "natsSubscription_GetPending", "group__sub_group.html#gaca6262e2ef842caa701a9f233db72707", null ],
    [ "natsSubscription_GetDelivered", "group__sub_group.html#ga476b7276d0b7f9946834d2bb2423e955", null ],
    [ "natsSubscription_GetDropped", "group__sub_group.html#ga24f1636869e26661ce62c9c9f4d80823", null ],
    [ "natsSubscription_GetMaxPending", "group__sub_group.html#ga0abc5d9afbc6b0c9c5adaf533904c968", null ],
    [ "natsSubscription_ClearMaxPending", "group__sub_group.html#gafe31911d8372db401d33856465421710", null ],
    [ "natsSubscription_GetStats", "group__sub_group.html#ga12b60cdb3aca7329edebc480ae86bfab", null ],
    [ "natsSubscription_IsValid", "group__sub_group.html#ga5e6454bbc7a90b9694112d45bd8de903", null ],
    [ "natsSubscription_Drain", "group__sub_group.html#ga26c9736289d326fb7d6df7e2a0df72ab", null ],
    [ "natsSubscription_WaitForDrainCompletion", "group__sub_group.html#ga0408c9b6e4ad4078ac0267656ace222d", null ],
    [ "natsSubscription_Destroy", "group__sub_group.html#ga50a95dd96e9b714201679a015d62832f", null ]
];