var searchData=
[
  ['wildcards',['Wildcards',['../group__wildcards_group.html',1,'']]]
];
