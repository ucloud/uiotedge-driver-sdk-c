var searchData=
[
  ['nats_5fdefault_5furl',['NATS_DEFAULT_URL',['../nats_8h.html#a911c54900b46b968205871cd9f68d36c',1,'nats.h']]],
  ['nats_5fextern',['NATS_EXTERN',['../nats_8h.html#a3bc1b3fe7f64083e60c7c3b93f205bad',1,'nats.h']]]
];
