var searchData=
[
  ['reconnecting',['RECONNECTING',['../status_8h.html#a6d667c1f8dd289a7e0f39bf10e800b51a1d5843fca4a8464bd4e24c90725352c0',1,'status.h']]]
];
