var modules =
[
    [ "Types", "group__types_group.html", "group__types_group" ],
    [ "Callbacks", "group__callbacks_group.html", "group__callbacks_group" ],
    [ "Functions", "group__func_group.html", "group__func_group" ],
    [ "Wildcards", "group__wildcards_group.html", null ],
    [ "Environment Variables", "group__env_variables_group.html", null ],
    [ "Libevent Adapter", "group__libevent_functions.html", "group__libevent_functions" ],
    [ "Libuv Adapter", "group__libuv_functions.html", "group__libuv_functions" ]
];